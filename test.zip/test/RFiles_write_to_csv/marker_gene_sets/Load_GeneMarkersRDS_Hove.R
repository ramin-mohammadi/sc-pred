setwd("C:/RaminMohammadi/CelliD_R/Mostafa_Datasets")

# in right pane, then click on the .rds file and load it, then you just write them to .csv files

write.csv(Hove_Mouse_MG[["B"]], "Hove_Mouse_MG_B.csv")


write.csv(Hove_Mouse_MG[["Microglia"]], "Hove_Mouse_MG_Microglia.csv")

write.csv(Hove_Mouse_MG[["NK"]], "Hove_Mouse_MG_NK.csv")

write.csv(Hove_Mouse_MG[["T_NKT"]], "Hove_Mouse_MG_T_NKT.csv")

write.csv(Hove_Mouse_MG[["cDC2"]], "Hove_Mouse_MG_cDC2.csv")

write.csv(Hove_Mouse_MG[["BAM"]], "Hove_Mouse_MG_BAM.csv")

write.csv(Hove_Mouse_MG[["Monocytes"]], "Hove_Mouse_MG_Monocytes.csv")

write.csv(Hove_Mouse_MG[["ILC"]], "Hove_Mouse_MG_ILC.csv")

write.csv(Hove_Mouse_MG[["yd_T"]], "Hove_Mouse_MG_yd_T.csv")

write.csv(Hove_Mouse_MG[["Neutrophils"]], "Hove_Mouse_MG_Neutrophils.csv")

write.csv(Hove_Mouse_MG[["pDC"]], "Hove_Mouse_MG_pDC.csv")

write.csv(Hove_Mouse_MG[["cDC1"]], "Hove_Mouse_MG_cDC1.csv")

write.csv(Hove_Mouse_MG[["migDC"]] , "Hove_Mouse_MG_migDC.csv")

